from flask import Flask, render_template, request , redirect, url_for, Blueprint


app = Flask(__name__, template_folder='static')

@app.route('/')
def index():
    return render_template('templates/index.html')

@app.route('/admin')
def login():
    return render_template('templates/admin.html')


if __name__ == "__main__":
    app.run()
